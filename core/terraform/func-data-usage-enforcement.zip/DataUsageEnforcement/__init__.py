import datetime, logging, math, re, os, socket, sys, uuid
import azure.functions as func

from azure.core.credentials import AzureNamedKeyCredential
from azure.data.tables import TableClient, UpdateMode
from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.fileshare import ShareClient

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info(f'>>> The timer is past due! {utc_timestamp}')

    # Read defined environment variables.
    MANAGED_IDENTITY_CLIENT_ID = os.getenv("MANAGED_IDENTITY_CLIENT_ID")
    SUBSCRIPTION_ID = os.getenv("SUBSCRIPTION_ID")
    ENVIRONMENT_PREFIX = os.getenv("ENVIRONMENT_PREFIX")
    CORE_STORAGE_ACCESS_KEY = os.getenv("CORE_STORAGE_ACCESS_KEY")
        
    # Use default credentials only for local debugging.
    # azure_credential = DefaultAzureCredential()

    # Authenticate using Managed Identity. To be used when the Function App is deployed.
    azure_credential = ManagedIdentityCredential(client_id=MANAGED_IDENTITY_CLIENT_ID)

    # Variables used for setting Core environment and Workspaces.
    workspace_prefix = f"rg-{ENVIRONMENT_PREFIX}-ws"

    core_storage_account = f"stg{ENVIRONMENT_PREFIX}"
    core_storage_table_url = f"https://{core_storage_account}.table.core.windows.net"

    storage_usage_table_name = "storageusage"
    per_study_usage_table_name = "perstudyusage"
    fileshare_usage_table_name = "fileshareusage"
    fileshare_name = "vm-shared-storage"

    # Retrieve a Stogage Account client so that we can read access keys from Storage Accounts
    storage_client = StorageManagementClient(azure_credential, SUBSCRIPTION_ID)    
    
    # Retrieve Resource Groups on the given subscription.
    resource_client = ResourceManagementClient(azure_credential, SUBSCRIPTION_ID)
    resource_groups = resource_client.resource_groups.list()

    # These lists will store dictionaries holding usage per workspace.
    computed_storage_usage_per_study = []
    computed_storage_usage_per_workspace = []
    computed_fileshare_usage_per_workspace = []

    # This variable is used for converting bytes into gigabytes.
    GBFACTOR = float(1<<30)
    # Iterate over Resource Groups.
    for resource_group in resource_groups:
        # We match the RG's according to the given resource group suffix.
        if re.search(f"^{workspace_prefix}", resource_group.name):      
            workspace_name_list = resource_group.name.split("-")
            workspace_short_id = workspace_name_list[3]
            
            workspace_keyvault_name = f"kv-{workspace_name_list[1]}-{workspace_name_list[2]}-{workspace_name_list[3]}"
            workspace_keyvault_url = f"https://{workspace_keyvault_name}.vault.azure.net"
            keyvault_client = SecretClient(vault_url=workspace_keyvault_url, credential=azure_credential)            
            
            workspace_id_secret = keyvault_client.get_secret("workspace-id")
            workspace_id = workspace_id_secret.value

            ssbs_storage_account_name = f"ssbsws{workspace_short_id}"
            workspace_ssbs_storage_account_fqdn = f"{ssbs_storage_account_name}.blob.core.windows.net"
            workspace_ssbs_storage_account_url = f"https://{workspace_ssbs_storage_account_fqdn}"

            stg_storage_account_name = f"stgws{workspace_short_id}"
            fileshare_account_fqdn = f"{stg_storage_account_name}.file.core.windows.net"
            fileshare_account_url = f"https://{fileshare_account_fqdn}"

            # Process SSBS Blob storage usage.
            try:
                # To avoid delays, we check if the SSBS exists (SSL do not have SSBS storage account).
                addr = socket.gethostbyname(workspace_ssbs_storage_account_fqdn)

                ssbs_storage_limits_secret = keyvault_client.get_secret("ssbs-storage-limits")
                ssbs_storage_limits = float(ssbs_storage_limits_secret.value)

                computed_size = 0

                # Create the BlobServiceClient object and retrieve containers
                blob_service_client = BlobServiceClient(workspace_ssbs_storage_account_url, credential=azure_credential)
                list_containers = blob_service_client.list_containers()

                # Retrive data usage for each container in the given Storage Account
                for container in list_containers:
                    container_client = ContainerClient(workspace_ssbs_storage_account_url, container['name'], credential=azure_credential)
                    try:                         
                        # This operation requires 'Storage Blob Data Reader' role.
                        list_blobs = container_client.list_blobs()
                        computed_size_per_study = 0

                        # Blob sizes are returned in bytes, we store them in GB.                        
                        for blob in list_blobs:
                            computed_size = computed_size + (blob['size'] / GBFACTOR)
                            computed_size_per_study = computed_size_per_study + (blob['size'] / GBFACTOR)
                        
                        # Storage computed usage per study (container).
                        computed_storage_usage_per_study.append({
                            "PartitionKey": "None",
                            "RowKey": uuid.uuid4(),                            
                            "ProtocolDataUsage": round(computed_size_per_study, 2),
                            "ProtocolId": container['name'],
                            "ProtocolPercentageUsage": 1.0 * math.floor((round(computed_size_per_study, 2) * 100) / ssbs_storage_limits),
                            "StorageLimits": ssbs_storage_limits,
                            "StorageName": ssbs_storage_account_name,                            
                            "WorkspaceId": workspace_id,
                            "WorkspaceName": resource_group.name          
                        })

                        # Useful log information.
                        logging.info(f">>> Retrieved usage for container \"{container['name']}({ssbs_storage_account_name})\" - Usage \"{computed_size_per_study}\"")

                    except Exception as ex:
                        logging.info(f">>> Unable to process container \"{container['name']}({ssbs_storage_account_name})\"")
                        logging.info(f"\t{ex}")

                # Storage computed usage per workspace.
                computed_storage_usage_per_workspace.append({
                    "PartitionKey": "None",
                    "RowKey": uuid.uuid4(),
                    "StorageLimits": ssbs_storage_limits,
                    "StorageName": ssbs_storage_account_name,                    
                    "StorageUsage": round(computed_size, 2),
                    "StoragePercentage": 1.0 * math.floor((round(computed_size, 2) * 100) / ssbs_storage_limits),
                    "WorkspaceId": workspace_id,
                    "WorkspaceName": resource_group.name
                })

                # Useful log information.
                logging.info(f">>> Retrieved usage for Storage Account \"{ssbs_storage_account_name}\" - Workspace \"{resource_group.name}\" - Usage \"{computed_size}\"")

            except Exception as ex:
                logging.info(f">>> Unable to process Storage Account: {ssbs_storage_account_name}")
                logging.info(f"\t{ex}")

            # Process Fileshare usage.
            try:
                # We are moving to Access Key authentication. Thus we need to retrieve the primary access key for the
                # for the storage account holding the fileshare.
                storage_account_keys_list = storage_client.storage_accounts.list_keys(resource_group_name=resource_group.name, account_name=stg_storage_account_name)
                primary_access_key = storage_account_keys_list.keys[0].value
                filesahe_key_credential=AzureNamedKeyCredential(f"{stg_storage_account_name}", f"{primary_access_key}")
                
                # Create the SharedClient object and get share size
                fileshare_service_client = ShareClient(account_url=fileshare_account_url, share_name=fileshare_name, credential=filesahe_key_credential)

                fileshare_properties = fileshare_service_client.get_share_properties()
                fileshare_storage_limits = float(fileshare_properties.quota)

                computed_size_bytes = fileshare_service_client.get_share_stats()                
                                
                computed_size = (computed_size_bytes / GBFACTOR)

                # Storage computed usage per workspace.
                computed_fileshare_usage_per_workspace.append({
                    "PartitionKey": "None",
                    "RowKey": uuid.uuid4(),                    
                    "FileshareLimits": fileshare_storage_limits,
                    "FilesharePercentage": 1.0 * math.floor((round(computed_size, 2) * 100) / fileshare_storage_limits),                    
                    "FileshareUsage": round(computed_size, 2),
                    "StorageName": stg_storage_account_name,
                    "WorkspaceId": workspace_id,
                    "WorkspaceName": resource_group.name
                })

                # Useful log information.
                logging.info(f">>> Retrieved usage for Fileshare \"{fileshare_name}({stg_storage_account_name})\" - Workspace \"{resource_group.name}\" - Usage \"{computed_size}\"")

            except Exception as ex:
                logging.info(f">>> Unable to process fileshare \"{fileshare_name}({stg_storage_account_name})\"")
                logging.info(f"\t{ex}")

    # Add SSBS Blob entries in Storage Account tables.
    azure_named_key_credential=AzureNamedKeyCredential(f"{core_storage_account}", f"{CORE_STORAGE_ACCESS_KEY}")
    try:
        table_client = TableClient(endpoint=core_storage_table_url,table_name=storage_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_storage_usage_per_workspace:
            new_entity = {
                "PartitionKey": f"{elem['PartitionKey']}",
                "RowKey": str(elem['RowKey']),
                "StorageLimits": elem['StorageLimits'],
                "StorageName": f"{elem['StorageName']}",
                "StorageUsage": elem['StorageUsage'],
                "StoragePercentage": elem['StoragePercentage'],
                "WorkspaceName": f"{elem['WorkspaceName']}",
                "WorkspaceId": f"{elem['WorkspaceId']}"
            }

            # Insert the entity
            table_client.create_entity(entity=new_entity)

        table_client = TableClient(endpoint=core_storage_table_url,table_name=per_study_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_storage_usage_per_study:
            new_entity = {                
                "PartitionKey": f"{elem['PartitionKey']}",
                "RowKey": str(elem['RowKey']),
                "ProtocolDataUsage": elem['ProtocolDataUsage'],
                "ProtocolId": f"{elem['ProtocolId']}",
                "ProtocolPercentageUsage": elem['ProtocolPercentageUsage'],                
                "StorageLimits": elem['StorageLimits'],
                "StorageName": f"{elem['StorageName']}",                
                "WorkspaceName": f"{elem['WorkspaceName']}",
                "WorkspaceId": f"{elem['WorkspaceId']}"
            }

            # Insert the entity
            table_client.create_entity(entity=new_entity)

        table_client = TableClient(endpoint=core_storage_table_url,table_name=fileshare_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_fileshare_usage_per_workspace:
            new_entity = {
                "PartitionKey": f"{elem['PartitionKey']}",
                "RowKey": str(elem['RowKey']),
                "FileshareLimits": elem['FileshareLimits'],
                "FileshareUsage": elem['FileshareUsage'],
                "FilesharePercentage": elem['FilesharePercentage'],
                "StorageName": f"{elem['StorageName']}",
                "WorkspaceId": f"{elem['WorkspaceId']}",
                "WorkspaceName": f"{elem['WorkspaceName']}"                
            }

            # Insert the entity
            table_client.create_entity(entity=new_entity)

    except Exception as ex:
        logging.info('Exception:')
        logging.info(f"\t{ex}")

    logging.info(f'>>> Python timer trigger function executed at {utc_timestamp}.')
