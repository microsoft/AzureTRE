import datetime, logging, math, re, os, sys
import azure.functions as func

from azure.identity import DefaultAzureCredential, ManagedIdentityCredential
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.storage.fileshare import ShareClient
from azure.mgmt.resource import ResourceManagementClient
from azure.data.tables import TableClient, UpdateMode
from azure.core.credentials import AzureNamedKeyCredential

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info(f'>>> The timer is past due! {utc_timestamp}')

    # Read defined environment variables.
    MANAGED_IDENTITY_CLIENT_ID = os.getenv("MANAGED_IDENTITY_CLIENT_ID")
    SUBSCRIPTION_ID = os.getenv("SUBSCRIPTION_ID")
    ENVIRONMENT_PREFIX = os.getenv("ENVIRONMENT_PREFIX")
    CORE_STORAGE_ACCESS_KEY = os.getenv("CORE_STORAGE_ACCESS_KEY")
        
    # Use default credentials only for local debugging.
    # azure_credential = DefaultAzureCredential()

    # Authenticate using Managed Identity. To be used when the Function App is deployed.
    azure_credential = ManagedIdentityCredential(client_id=MANAGED_IDENTITY_CLIENT_ID)

    # Variables used for setting Core environment and Workspaces.
    workspace_prefix = f"rg-{ENVIRONMENT_PREFIX}-ws"

    core_storage_account = f"stg{ENVIRONMENT_PREFIX}"
    core_storage_table_url = f"https://{core_storage_account}.table.core.windows.net"

    storage_usage_table_name = "storageusage"
    per_study_usage_table_name = "perstudyusage"
    fileshare_usage_table_name = "fileshareusage"
    fileshare_name = "vm-shared-storage"

    # Retrieve Resource Groups on the given subscription.
    try:
        resource_client = ResourceManagementClient(azure_credential, SUBSCRIPTION_ID)
        resource_groups = resource_client.resource_groups.list()

    except Exception as ex:
        logging.info('Exception:')
        logging.info(f"\t{ex}")

    # These lists will store dictionaries holding usage per workspace.
    computed_storage_usage_per_study = []
    computed_storage_usage_per_workspace = []
    computed_fileshare_usage_per_workspace = []

    # This variable is used for converting bytes into gigabytes.
    GBFACTOR = float(1<<30)
    # Iterate over Resource Groups.
    for resource_group in resource_groups:
        # We match the RG's according to the given resource group suffix.
        if re.search(f"^{workspace_prefix}", resource_group.name):
            workspace_id_list = resource_group.name.split("-")
            workspace_id = workspace_id_list[3]

            storage_account_name = f"stgws{workspace_id}"
            ssbs_storage_account_name = f"ssbsws{workspace_id}"
            # workspace_storage_account_url = f"https://{storage_account_name}.blob.core.windows.net"
            workspace_ssbs_storage_account_url = f"https://{ssbs_storage_account_name}.blob.core.windows.net"
            fileshare_account_url = f"https://{storage_account_name}.file.core.windows.net"

            # Process Blob storage usage.
            try:
                computed_size = 0

                # Create the BlobServiceClient object and retrieve containers
                blob_service_client = BlobServiceClient(workspace_ssbs_storage_account_url, credential=azure_credential)
                list_containers = blob_service_client.list_containers()

                # Retrive data usage for each container in the given Storage Account
                for container in list_containers:
                    container_client = ContainerClient(workspace_ssbs_storage_account_url, container['name'], credential=azure_credential)
                    try:                         
                        # This operation requires 'Storage Blob Data Reader' role.
                        list_blobs = container_client.list_blobs()
                        computed_size_per_study = 0

                        # Blob sizes are returned in bytes, we store them in GB.                        
                        for blob in list_blobs:
                            computed_size = computed_size + (blob['size'] / GBFACTOR)
                            computed_size_per_study = computed_size_per_study + (blob['size'] / GBFACTOR)
                        
                        # Storage computed usage per study (container).
                        computed_storage_usage_per_study.append({
                            "WorkspaceName": resource_group.name,
                            "StorageName": ssbs_storage_account_name,
                            "ProtocolDataUsage": round(computed_size_per_study, 2),
                            "ProtocolId": container['name'].replace("-", "_"),
                            "UpdateTime": utc_timestamp
                        })

                        # Useful log information.
                        logging.info(f">>> Retrieved usage for container \"{container['name']}({ssbs_storage_account_name})\" - Usage \"{computed_size_per_study}\"")

                    except Exception as ex:
                        logging.info(f">>> Unable to process container \"{container['name']}({ssbs_storage_account_name})\"")
                        logging.info(f"\t{ex}")

                # Storage computed usage per workspace.
                computed_storage_usage_per_workspace.append({
                    "WorkspaceName": resource_group.name,
                    "StorageName": ssbs_storage_account_name,
                    "StorageUsage": round(computed_size, 2),
                    "UpdateTime": utc_timestamp
                })

                # Useful log information.
                logging.info(f">>> Retrieved usage for Storage Account \"{ssbs_storage_account_name}\" - Workspace \"{resource_group.name}\" - Usage \"{computed_size}\"")

            except Exception as ex:
                logging.info(f">>> Unable to process Storage Account: {ssbs_storage_account_name}")
                logging.info(f"\t{ex}")

            # Process Fileshare usage.
            try:
                # Create the SharedClient object and get share size
                fileshare_service_client = ShareClient(fileshare_account_url, share_name=fileshare_name, credential=azure_credential, token_intent='backup')
                computed_size_bytes = fileshare_service_client.get_share_stats()                
                computed_size = (computed_size_bytes / GBFACTOR)

                # Storage computed usage per workspace.
                computed_fileshare_usage_per_workspace.append({
                    "WorkspaceName": resource_group.name,
                    "StorageName": storage_account_name,
                    "FileshareUsage": round(computed_size, 2),
                    "UpdateTime": utc_timestamp
                })

                # Useful log information.
                logging.info(f">>> Retrieved usage for Fileshare \"{fileshare_name}({storage_account_name})\" - Workspace \"{resource_group.name}\" - Usage \"{computed_size}\"")

            except Exception as ex:
                logging.info(f">>> Unable to process fileshare \"{fileshare_name}({storage_account_name})\"")
                logging.info(f"\t{ex}")

    # Update Blob storage usage in Storage Account tables.
    azure_named_key_credential=AzureNamedKeyCredential(f"{core_storage_account}", f"{CORE_STORAGE_ACCESS_KEY}")
    try:
        table_client = TableClient(endpoint=core_storage_table_url,table_name=storage_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_storage_usage_per_workspace:
            parameters = {"workspacename": elem['WorkspaceName'], "storagename": elem['StorageName']}
            workspace_filter = "WorkspaceName eq @workspacename and StorageName eq @storagename"

            # Filter table entities using workspace name and storage account name.
            entities = table_client.query_entities(
                query_filter=workspace_filter,
                parameters=parameters
            )

            # Only 1 interation should happen.
            for entity in entities:
                # Create a new entity to replace the old one.
                new_entity = {
                    "PartitionKey": entity['PartitionKey'],
                    "RowKey": entity['RowKey'],
                    "WorkspaceName": entity['WorkspaceName'],
                    "StorageName": entity['StorageName'],
                    "StorageUsage": elem['StorageUsage'],
                    "StorageLimits": entity['StorageLimits'],
                    "StorageLimitsUpdateTime": entity['StorageLimitsUpdateTime'],
                    "StoragePercentage": math.floor(((elem['StorageUsage'] * 100.0) / entity['StorageLimits'])),
                    "UpdateTime": elem['UpdateTime']
                }

                # Merge the entity
                table_client.update_entity(mode=UpdateMode.MERGE, entity=new_entity)

        table_client = TableClient(endpoint=core_storage_table_url,table_name=per_study_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_storage_usage_per_study:
            parameters = {"workspacename": elem['WorkspaceName'], "protocolid": elem['ProtocolId']}
            workspace_filter = "WorkspaceName eq @workspacename and ProtocolId eq @protocolid"

            # Filter table entities using workspace name and storage account name.
            entities = table_client.query_entities(
                query_filter=workspace_filter,
                parameters=parameters
            )

            # Only 1 interation should happen.
            for entity in entities:
                # Create a new entity to replace the old one.
                new_entity = {
                    "PartitionKey": entity['PartitionKey'],
                    "RowKey": entity['RowKey'],
                    "WorkspaceName": entity['WorkspaceName'],
                    "ProtocolDataUsage": elem['ProtocolDataUsage'],
                    "ProtocolId": entity['ProtocolId'],
                    # "ProtocolPercentageUsage": math.floor(((elem['FileshareUsage'] * 100.0) / entity['FileshareLimits']))
                    "StorageName": entity['WorkspaceName'],
                    "UpdateTime": elem['UpdateTime']
                }

                # Merge the entity
                table_client.update_entity(mode=UpdateMode.MERGE, entity=new_entity)

        table_client = TableClient(endpoint=core_storage_table_url,table_name=fileshare_usage_table_name,credential=azure_named_key_credential)
        for elem in computed_fileshare_usage_per_workspace:
            parameters = {"workspacename": elem['WorkspaceName'], "storagename": elem['StorageName']}
            workspace_filter = "WorkspaceName eq @workspacename and StorageName eq @storagename"

            # Filter table entities using workspace name and storage account name.
            entities = table_client.query_entities(
                query_filter=workspace_filter,
                parameters=parameters
            )

            # Only 1 interation should happen.
            for entity in entities:
                # Create a new entity to replace the old one.
                new_entity = {
                    "PartitionKey": entity['PartitionKey'],
                    "RowKey": entity['RowKey'],
                    "WorkspaceName": entity['WorkspaceName'],
                    "StorageName": entity['StorageName'],
                    "FileshareUsage": elem['FileshareUsage'],
                    "FileshareLimits": entity['FileshareLimits'],
                    "FileshareLimitsUpdateTime": entity['FileshareLimitsUpdateTime'],
                    "FilesharePercentage": 1.0 * math.floor(((elem['FileshareUsage'] * 100.0) / entity['FileshareLimits'])),
                    "UpdateTime": elem['UpdateTime']
                }

                # Merge the entity
                table_client.update_entity(mode=UpdateMode.MERGE, entity=new_entity)

    except Exception as ex:
        logging.info('Exception:')
        logging.info(f"\t{ex}")

    logging.info(f'>>> Python timer trigger function executed at {utc_timestamp}.')
